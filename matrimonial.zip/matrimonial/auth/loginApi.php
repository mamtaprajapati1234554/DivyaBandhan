<?php

session_start();

require_once("../config/database.php");

// Allow only POST requests
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: login.php");
    exit;
}

// Get form data
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

// Validate
if (empty($email) || empty($password)) {
    $_SESSION['error'] = "Email and Password are required";
    header("Location: login.php");
    exit;
}

try {

    // Find user
    $stmt = $pdo->prepare("
        SELECT id, first_name, last_name, email, password
        FROM users
        WHERE email = :email
        LIMIT 1
    ");

    $stmt->execute([
        ':email' => $email
    ]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verify password
    if ($user && password_verify($password, $user['password'])) {

        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['first_name'];

        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

        header("Location: ../dashboard/index.php");
        exit;
    }

    $_SESSION['error'] = "Invalid Email or Password";
    header("Location: login.php");
    exit;

} catch (PDOException $e) {

    die("Database Error: " . $e->getMessage());

}