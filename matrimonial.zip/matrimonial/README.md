<nav class="home-navbar">

    <div class="logo">
        <a href="#">DivyaBandhan</a>
    </div>

    <ul class="nav-menu">
        <li><a href="#">Home</a></li>
        <li><a href="#">Active Members</a></li>
        <li><a href="#">Premium Plans</a></li>
        <li><a href="#">Happy Stories</a></li>
        <li><a href="#">Contact</a></li>
    </ul>

    <div class="auth-buttons">
        <a href="login.php" class="login-btn">Login</a>
        <a href="register.php" class="register-btn">Register</a>
    </div>

</nav>