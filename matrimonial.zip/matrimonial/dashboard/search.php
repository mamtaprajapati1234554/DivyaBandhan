<?php
session_start();
?>

<!DOCTYPE html>

<html>

<head>

<title>Search</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<?php include("../includes/dashboard-header.php"); ?>

<div class="container mt-5">

<h2>Search Members</h2>

<form class="row">

<div class="col-md-4">

<input type="text" class="form-control" placeholder="City">

</div>

<div class="col-md-4">

<select class="form-select">

<option>Religion</option>

</select>

</div>

<div class="col-md-4">

<button class="btn btn-danger">

Search

</button>

</div>

</form>

</div>

</body>

</html>