<?php
session_start();

if(!isset($_SESSION['user_id']))
{
header("Location: ../auth/login.php");
exit();
}

include("../config/database.php");
?>

<!DOCTYPE html>

<html>

<head>

<title>My Profile</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<?php include("../includes/dashboard-header.php"); ?>

<div class="container mt-5">

<h2>My Profile</h2>

<hr>

<form>

<div class="mb-3">
<label>Name</label>
<input type="text" class="form-control">
</div>

<div class="mb-3">
<label>City</label>
<input type="text" class="form-control">
</div>

<div class="mb-3">
<label>Religion</label>
<input type="text" class="form-control">
</div>

<button class="btn btn-primary">
Update
</button>

</form>

</div>

</body>

</html>