<?php
session_start();
include("../config/database.php");

$email = $_SESSION['email'];

// Logged-in user ki ID nikaalo
$userQuery = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
$user = mysqli_fetch_assoc($userQuery);

$loginUserId = $user['id'];

// Sirf dusre members dikhao
$sql = "SELECT
users.id,
users.first_name,
users.last_name,
users.gender,

profiles.education,
profiles.occupation,
profiles.salary,
profiles.city,
profiles.state,
profiles.profile_photo

FROM users

INNER JOIN profiles
ON users.id = profiles.user_id

WHERE users.id != '$loginUserId'";

$result = mysqli_query($conn, $sql);
?>