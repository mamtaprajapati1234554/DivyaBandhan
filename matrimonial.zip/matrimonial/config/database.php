<?php

$host = "localhost";
$dbname = "divyabandhan";
$user = "root";
$pass = "";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname",
        $user,
        $pass
    );

    // Enable exception mode
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // echo "Database connected successfully";

} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}