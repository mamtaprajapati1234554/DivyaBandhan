<?php
session_start();
require_once("config/database.php");

$stmt = $pdo->prepare("
    SELECT u.first_name, u.last_name, p.city, p.profile_photo
    FROM users u
    INNER JOIN profiles p ON u.id = p.user_id
    LIMIT 4
");
$stmt->execute();
$premiumMembers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DivyaBandhan - Home</title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="assets/css/premium-members.css">
    
</head>
<body>

    <?php include("includes/home-navbar.php"); ?>

    <section class="hero-section">
        <img src="assets/images/background1.jpg" alt="banner" class="hero-img">

        <div class="hero-text">
            <h1>Two Hearts, One Beautiful Forever</h1>
            <h1 class="highlight">Make Yours Special</h1>
        </div>

        <div class="register-card">
            <h3>Create Your Account</h3>
            <p>Fill out the form to get started</p>
        </div>
    </section>

    <section class="premium-section">
        <h2>Premium Members</h2>
        <p>Every premium member is verified and privileged by our policy & rules so you don't have to worry about your privacy or security.</p>

        <div class="premium-grid">
            <?php if (count($premiumMembers) > 0): ?>
                <?php foreach ($premiumMembers as $member): ?>
                    <div class="premium-card">
                        <img src="assets/images/profiles/<?= htmlspecialchars($member['profile_photo'] ?: 'default.jpg') ?>" alt="profile">
                        <div class="info">
                            <h4><?= htmlspecialchars($member['first_name']) ?></h4>
                            <p><?= htmlspecialchars($member['city']) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="no-data">No members yet.</p>
            <?php endif; ?>
        </div>
    </section>

</body>
</html>
