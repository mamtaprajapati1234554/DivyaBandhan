<div class="card shadow-sm mb-4">

    <div class="row">

        <div class="col-md-4">

            <?php

            if(!empty($row['profile_photo']))
            {
            ?>

            <img src="../uploads/<?php echo $row['profile_photo'];?>"
            class="img-fluid rounded-start">

            <?php
            }
            else
            {
            ?>

            <img src="../assets/images/default.png"
            class="img-fluid rounded-start">

            <?php
            }
            ?>

        </div>

        <div class="col-md-8">

            <div class="card-body">

                <h4>

                    <?php
                    echo $row['first_name']." ".$row['last_name'];
                    ?>

                </h4>

                <p>

                    📍
                    <?php
                    echo $row['city'];
                    ?>
                    ,
                    <?php
                    echo $row['state'];
                    ?>

                </p>

                <p>

                    💼
                    <?php
                    echo $row['occupation'];
                    ?>

                </p>

                <p>

                    🎓
                    <?php
                    echo $row['education'];
                    ?>

                </p>

                <p>

                    ₹
                    <?php
                    echo $row['salary'];
                    ?>

                </p>

                <a href="#" class="btn btn-danger btn-sm">
                    Interest
                </a>

                <a href="#" class="btn btn-primary btn-sm">
                    Chat
                </a>

            </div>

        </div>

    </div>

</div>