<?php
$userName = $_SESSION['name'] ?? 'User';
?>

<div class="card shadow-sm border-0 rounded-4">

    <!-- Profile -->
    <div class="card-body text-center">

        <img src="../assets/images/profile.png"
             class="rounded-circle border"
             width="90"
             height="90"
             alt="Profile">

        <h4 class="mt-3 mb-1">
            Hi <?php echo $userName; ?>!
        </h4>

        <small class="text-muted">
            Welcome Back
        </small>

        <br>

        <a href="profile.php" class="text-decoration-none fw-semibold">
            Edit Profile
        </a>

    </div>

    <hr class="m-0">

    <!-- Menu -->

    <div class="list-group list-group-flush">

        <a href="index.php"
           class="list-group-item list-group-item-action border-0 py-3">
            🏠 Dashboard
        </a>

        <a href="matches.php"
           class="list-group-item list-group-item-action border-0 py-3">
            ❤️ Matches
        </a>

        <a href="search.php"
           class="list-group-item list-group-item-action border-0 py-3">
            🔍 Search Members
        </a>

        <a href="interests.php"
           class="list-group-item list-group-item-action border-0 py-3">
            💌 Interests
        </a>

        <a href="shortlist.php"
           class="list-group-item list-group-item-action border-0 py-3">
            ⭐ Shortlist
        </a>

        <a href="message.php"
           class="list-group-item list-group-item-action border-0 py-3">
            💬 Messages
        </a>

        <a href="profile.php"
           class="list-group-item list-group-item-action border-0 py-3">
            👤 My Profile
        </a>

        <a href="settings.php"
           class="list-group-item list-group-item-action border-0 py-3">
            ⚙ Settings
        </a>

        <a href="../auth/logout.php"
           class="list-group-item list-group-item-action border-0 text-danger py-3">
            🚪 Logout
        </a>

    </div>

</div>